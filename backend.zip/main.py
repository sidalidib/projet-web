from flask import Flask, render_template, request, send_file, jsonify, redirect, session
import transformers
from transformers import BloomForCausalLM
from transformers import BloomTokenizerFast
from datetime import datetime
import re
import torch
from creation_table import db, Users, Conversations, Sessions, Messages
from flask.templating import render_template, request
import os


# create the app
app = Flask(__name__)
# configure the SQLite database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
# initialize the app with the extension
db.init_app(app)

app.config['SECRET_KEY'] = os.urandom(24) 

with app.app_context():
    db.create_all()


model = BloomForCausalLM.from_pretrained("bigscience/bloom-1b1")
tokenizer = BloomTokenizerFast.from_pretrained("bigscience/bloom-1b1")
result_length = 50

@app.route('/api/chat', methods=['POST'])
def chatIDA():
    
    data = request.get_json()
    question = data["question"]
    
    time1 = datetime.now()
    time2 = datetime.now()
    return jsonify({"question":question, "answer":"Salam frr", "question_datetime":time1, "answer_datetime":time2})
    
    prompt = """ 
Q: Bonjour
A: Bonjour, comment je peux t'aider ?
Q: Qui es-tu ?
A: Je suis un chatbot créé par Sidali DIB
Q: De quoi tu es capable ?
A: Je suis capable de répondre à des questions de manière pertinente dans les plus brefs délais
Q: <question>
A: """
    
    conversation_history = ""
    
    #prompt = prompt.replace("<conversation history>", conversation_history)
    prompt = prompt.replace("<question>", question)
    
    inputs = tokenizer(prompt, return_tensors="pt")["input_ids"]
    inputSize = len(inputs[0])
    # Sampling Top-k + Top-p
    answerToken = model.generate(inputs,
                        max_new_tokens=result_length, 
                        num_beams=3, 
                        no_repeat_ngram_size=2,
                        early_stopping=True
                        )[0]
    answer = tokenizer.decode(answerToken[inputSize:])
    
    
    
    print(prompt)
    answer = re.split("Q:|Q :",answer)[0]
    print(answer)
    return jsonify({"question":question, "answer":answer})
        
        

@app.route('/api/listConversation', methods=['POST'])
def send():
    # session['key'] = 'value'
    user_id = session.get('user_id')
    if not user_id:
        return {'error':"not login"}
    else:
        return "Hello Boss!"


@app.route('/api/logout', methods=['POST'])
def logout():
    session['user_id']=False
    return {"success":False}
    

@app.route('/api/inscrire', methods=['POST'])
def inscrire():
    data = request.get_json()
    print(data)
    username = data['username']
    email_inscription = data['email_inscription'] 
    password_inscription = data['password_inscription']

    with app.app_context():
        user = Users(user_name=username ,password=password_inscription,email=email_inscription)
        exists = db.session.execute(db.select(Users).filter_by(email=email_inscription)).scalar()
        print(exists)
        if (exists):
            return {"success":False,'error':"mail already registed"}
        else:
            db.session.add(user)
            db.session.commit()
            return {"success":True}


@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    print(data)
    email_login = data['email_login']
    password_login = data['password_login'] 

    with app.app_context():
        exists = db.session.execute(db.select(Users).filter_by(email=email_login)).scalar()
        print(exists)
        if (exists):
            if (exists.password == password_login):
                session['user_id'] = exists.user_id
                return {"success":True}
            else :
                return {"success":False,'error':"password incorrect"}
        else:
            return {"success":False,'error':"user not exists"}




if __name__=='__main__':
    app.run(port=4000, debug=False)
    

    
    