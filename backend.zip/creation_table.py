from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
# from sqlalchemy import MetaData


# create the extension
db = SQLAlchemy()

  

class Users(db.Model):
    user_id = Column(Integer, primary_key=True, autoincrement=True)
    user_name = Column(String, nullable=False)
    password = Column(Text, nullable=False)
    email = Column(String, unique=True)
# Users = db.Table(
#     "users",
#     metadata_obj,
#     Column("user_id", Integer, primary_key=True),
#     Column("user_name", String, nullable=False),
#     Column("password", String, nullable=False),
#     Column("email", String(60), unique=True )
# )


class Conversations(db.Model):
    conversation_id = Column(Integer, primary_key=True, autoincrement=True)
    user_id= Column(Integer,ForeignKey(Users.user_id), nullable=False)

# Conversations = db.Table(
#     "conversations",
#     metadata_obj,
#     Column("conversation_id", Integer, primary_key=True),
#     Column("user_id", Integer, ForeignKey("Users.user_id"), primary_key=True)
# )


class Sessions(db.Model):
    session_id = Column(Integer, primary_key=True, autoincrement=True)
    user_id= Column(Integer,ForeignKey(Users.user_id), nullable=False)

# Sessions = db.Table(
#     "sessions",
#     metadata_obj,
#     Column("session_id", Integer, primary_key=True),
#     Column("user_id", Integer, ForeignKey("Users.user_id"), primary_key=True)
# )


class Messages(db.Model):
    message_id = Column(Integer, primary_key=True, autoincrement=True)
    conversation_id = Column(Integer, ForeignKey(Conversations.conversation_id), nullable=False)
    session_id = Column(Integer, ForeignKey(Sessions.session_id), nullable=False)
    user_message = Column(Text, nullable=False)
    bot_message = Column(Text, nullable=False)
    user_date = Column(DateTime, nullable=False)
    bot_date = Column(DateTime, nullable=False)

# Messages = db.Table(
#     "messages",
#     metadata_obj,
#     Column("message_id", Integer, primary_key=True),
#     Column("conversation_id", Integer, ForeignKey("Conversations.conversation_id"), primary_key=True),
#     Column("session_id", Integer, ForeignKey("Sessions.session_id"), primary_key=True),
#     Column("user_message", Text, nullable=False),
#     Column("bot_message", Text, nullable=False),
#     Column("user_date", DateTime, nullable=False),
#     Column("bot_date", DateTime, nullable=False),
# )
# metadata_obj.create_all(engine)
    

    
    