<template>

  <v-navigation-drawer permanent location="left" class="nav" color="#333">
    <v-list>
      <v-list-item
        prepend-avatar="../assets/icone-utilisateur-gris.png"
        title="DIB Sidali"
        subtitle="thedibsidali@gmail.com">
      </v-list-item>
    </v-list>

    <v-divider></v-divider>

    <v-btn class="create_conversation_button" prepend-icon="mdi-plus" v-on:click="logout">New conversation</v-btn>
    <v-list class="historique">
      
    </v-list>
    <v-btn class="logout_button" prepend-icon="mdi-lock" v-on:click="logout">Logout</v-btn>
  </v-navigation-drawer>

  <div class="chat">
    <v-card class="mx-16 my-4" height="400" overflow-y="scroll">
        <v-list-item v-for="[question, answer, time1, time2] in messages" :key="question">
          <label class="time1">{{ time1 }}</label>
          <v-card-text class="question">{{ question }}</v-card-text>
          <label class="time2">{{ time2 }}</label>
          <v-card-text class="answer">{{ answer }}</v-card-text>
        </v-list-item>
    </v-card>
    <v-form class="input" ref="form" v-on:submit.prevent="getAnswer" :disabled="!available">
      <v-text-field class="text-field" v-model="question" label="Enter your message" variant="solo"
      clearable @click:clear="setInputEmpty()"/>
      <v-btn class="send_button" icon="mdi-send" v-on:click="getAnswer" :disabled="!available"></v-btn>
    </v-form>
  </div>

</template>



<script>
  export default {
    emits: ['loggedout'],

    data: () => ({
      question:'',
      answer:'',
      time1:'',
      time2:'',
      nb_msg:0,
      messages: [],
      conversations: [],
      available: true
    }),

    methods:{
      setInputEmpty(){
        this.question = ""
      },

      async getAnswer(){ 
        this.available = false
        this.messages.push([this.question, "...", "", ""])
        this.$refs.form.reset()
        fetch('/api/chat',{
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          method: "POST",
          body: JSON.stringify({question:this.question})
        }).then(res=>res.json()).then(data=>{
          console.log(data)
          this.messages[this.nb_msg][1] = data.answer
          this.messages[this.nb_msg][2] = data.question_datetime
          this.messages[this.nb_msg][3] = data.answer_datetime
          this.available = true
          this.nb_msg += 1
        })
      },

      logout(){ 
        fetch('/api/logout',{
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          method: "POST",
        }).then(res=>res.json()).then(data=>{
          this.$emit("loggedout", data['success'])
        })
      },

      changeConversation(newUrl){
        console.log(newUrl)
        this.url=newUrl
      }

  },

  components: {
       
  }

}


</script>



<style>

.historique {
  flex: 70%;
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  justify-content: center;
  padding: 10px;
}

.nav {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  justify-content: center;
  background-color: #333;
}

.profile {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  justify-content: center;
  padding: 10px;
}

.text-field {
  border-radius: 8px;
  margin-right: 10px;
}

.logout_button {
  top: 59%;
  left: 25%;
}

.create_conversation_button {
  top: 2%;
  left: 7%;
}

.send_button, .logout_button, .create_conversation_button {
    background-color: #aaa;
    color: black;
    text-align: center;
    margin: 5px;
    padding: 5px;
}

.send_button:hover, .logout_button:hover, .create_conversation_button:hover {
    border: 1.5px solid greenyellow;
}

.input {
  position: fixed;
  right: 35px;
  bottom: 20px;
  flex: 0;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  border-radius: 4px;
  width: 70%;
  margin: 10px;
  padding: 5px;
}

.conversation {
  background-color: white;
  flex: 1;
  display: flex;
  flex-wrap: nowrap;
  flex-direction: column;
  justify-content: start;
  position: fixed;
  top: 70px;
  right: -13px;
  margin-top: 20px;
  margin-bottom: 50px;
  margin-left: 70px;
  margin-right: 70px;
}

.chat {
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  justify-content: center;
}

.question {
  margin: 10px;
  margin-top: 2px;
  margin-left: 180px;
  padding: 5px;
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  text-align: left;
  border-radius: 6px;
  background-color: #f5f5f5;
  color: black;
}

.time1 {
  font-size: 12px;
  margin-left: 185px;
  text-align: right;
}

.answer {
  margin: 10px;
  margin-top: 2px;
  margin-right: 180px;
  padding: 5px;
  display: flex;
  text-align: left;
  flex-direction: row;
  flex-wrap: nowrap;
  border-radius: 6px;
  background-color: #f5f5f5;
  color: black;
}

.time2 {
  margin-left: 15px;
  font-size: 12px;
}

footer {
    flex: 0;
    background-color: #333;
    color: #eee
}

footer p {
  text-align: center;
}

</style>