<template>
  <v-app >
     <v-main>
        <v-container fluid fill-height>
              <div class="formulaire">
                 <v-card class="elevation-12">
                    <v-toolbar dark color="primary">
                       <v-toolbar-title>Login</v-toolbar-title>
                    </v-toolbar>
                    <v-card-text class="login">
                    <form ref="form" @submit.prevent="login()">
                           <v-text-field
                             v-model="email_login"
                             name="email_login"
                             label="Email"
                             type="string"
                             placeholder="email"
                             required
                          ></v-text-field>
                          
                           <v-text-field
                             v-model="password_login"
                             name="password"
                             label="Password"
                             type="password"
                             placeholder="password"
                             required
                          ></v-text-field>
                          <v-btn type="submit" class="mt-4" color="primary" value="login">Login</v-btn>
                     </form>
                    </v-card-text>
                 </v-card>


                 <v-card class="elevation-12">
                    <v-toolbar dark color="primary">
                       <v-toolbar-title>Inscription</v-toolbar-title>
                    </v-toolbar>
                    <v-card-text class="login">
                    <form ref="form" @submit.prevent="inscrire">
                           <v-text-field
                             v-model="username"
                             name="username"
                             label="Username"
                             type="string"
                             placeholder="username"
                             required
                          ></v-text-field>

                          <v-text-field
                             v-model="email_inscription"
                             name="email_inscription"
                             label="Email"
                             type="string"
                             placeholder="email"
                             required
                          ></v-text-field>

                           <v-text-field
                             v-model="password_inscription"
                             name="password_inscription"
                             label="Password"
                             type="password"
                             placeholder="password"
                             required
                          ></v-text-field>

                          <v-text-field
                             v-model="password_confirm"
                             name="confirm_password"
                             label="Confirm Password"
                             type="password"
                             placeholder="confirm password"
                             required
                          ></v-text-field>
                          <v-btn type="submit" class="mt-4" color="primary" value="inscrire">Inscrire</v-btn>
                     </form>
                    </v-card-text>
                 </v-card>
               
                </div>
        </v-container>
     </v-main>
  </v-app>
</template>

<script>
export default {
 name: "Login",
 emits:['logged'],
 data() {
   return {       
     email_login: "",
     password_login: "",
     
     username: "",
     email_inscription: "",
     password_inscription: "",
     password_confirm: ""


   };
 },
 methods: {
   login() {
    const bodyMsg = {
      email_login: this.email_login,
      password_login: this.password_login}
      console.log(bodyMsg)

      fetch('/api/login',{
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(bodyMsg)
      })
      .then(res=>res.json()).then(json=>{
        this.$emit('logged', json['success'])
      })
      
   },

   inscrire() {
    const bodyMsg = {
      username: this.username,
      email_inscription: this.email_inscription,
      password_inscription: this.password_inscription}
      console.log(bodyMsg)

      if(this.password_inscription.length<8){
        console.log("password too short")
      }
      else if(this.password_inscription === this.password_confirm){
        fetch('/api/inscrire',{
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          method: "POST",
          body: JSON.stringify(bodyMsg)
        })
        .then(res=>res.json()).then(json=>{
          console.log(json)
          this.$emit('logged',json['success'])
        })
        // is_login = True
      }
      else {
        console.log("password not same")
      }
   }
 },
};
</script>

<style>
.formulaire {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-evenly;
}

.login {
  width: 30vw;
}

.elevation-12 {
  text-align: center;
}
</style>