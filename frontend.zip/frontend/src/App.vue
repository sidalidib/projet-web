<template>
  <v-app>
    <v-system-bar class="header">
      <v-spacer></v-spacer>
      <label>ChatIDA</label>
      <v-spacer></v-spacer>
    </v-system-bar>

    <v-main class="main">
      <Chat v-if="islogin" v-on:loggedout="updateLogged" />
      <Login v-if="!islogin" v-on:logged="updateLogged"/>
    </v-main>

    <footer>
        <p>Copyright &#169; DIB Sidali & GUAN Yu Rui</p>
    </footer>
  </v-app>
</template>



<script>

  import Chat from "./components/Chat.vue"
  import Login from "./components/Login.vue"
  export default {
    data: () => ({
      islogin: false,
    }),

    methods:{
      logout() {
        this.islogin=false;
      },
      updateLogged(status){
      this.islogin = status
      }
    },
    components: {
        Chat, Login
    }
  }


</script>



<style>

.header, footer {
  flex: 0;
  background-color: #eee;
  color: black
}

footer p {
  text-align: center;
  font-size: 12px;
}



</style>